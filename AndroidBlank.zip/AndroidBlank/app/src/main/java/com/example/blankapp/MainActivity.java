package com.example.blankapp;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView text = new TextView(this);
        text.setText("کتاب من\n\nاین برنامه آماده است.\n\nبعداً متن‌ها، فصل‌ها و کتاب‌ها را به آن اضافه می‌کنیم.");
        text.setTextSize(22);
        text.setTextColor(Color.DKGRAY);
        text.setGravity(Gravity.CENTER);
        text.setPadding(40, 40, 40, 40);
        setContentView(text);
    }
}
