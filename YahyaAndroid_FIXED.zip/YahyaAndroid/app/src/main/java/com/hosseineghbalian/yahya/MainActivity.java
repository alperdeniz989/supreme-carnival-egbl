package com.hosseineghbalian.yahya;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import android.graphics.Typeface;

public class MainActivity extends Activity {
  String book = """
شهر در تب و تاب خود می‌سوزد؛
شبیه آهوی تیرخورده‌ای
که در خویش می‌پیچد
مرگ، پشت پنجره ایستاده است...
ماه از دریچه فریاد می‌زند
و کودکان بازیگوش،
به خوشه‌چینی ستاره‌ها،
بمب‌ها را نظاره می‌کنند

اسم من یحیی ست

انگار وسط همه ماجراها، صدای زنگ مدرسه از همه مهمتر بود. پشت دوچرخه پدربزرگ، با آن قیافه تر و تمیز و پالتوی رنگ‌ورورفته، زنبیلی پر از سبزی خوردنی بود.

پدربزرگ همیشه روبروی مدرسه نائب منتظر یحیی می‌ماند. زنگ مدرسه که به صدا درمی‌آمد، یحیی با کیفش می‌دوید و پدربزرگ او را روی ترک دوچرخه سوار می‌کرد.

نائب سرباز دهه شصت بود؛ داوطلبی جوان و سخت وطن‌پرست. پدربزرگ هیچ‌وقت نائب را بدون لباس خاکی ندیده بود. خاطره نائب سال‌ها در ذهن سلطان مانده بود.

خانه پدربزرگ حیاطی بزرگ داشت و در انتهای آن خانه‌ای کوچک با بالکنی زیبا بود. میان کاشی‌ها سبزه و گل‌های بابونه روییده بود. روی بالکن یک تلسکوپ بود و یحیی شب‌ها با آن آسمان را نگاه می‌کرد.

یحیی شازده کوچولو را دوست داشت. تمام جمله‌های کتاب را حفظ کرده بود و شب‌ها برای پدربزرگ می‌خواند. سلطان گوش می‌داد و گاهی وانمود می‌کرد خوابیده است.

اما جنگ دوباره به شهر برگشته بود.

بمب‌ها روی سر شهر ریخته بودند. صدای جیرجیرک‌ها زیر آوار خفه شده بود. کفش‌های لیلا وسط کوچه افتاده بود و ورق‌های سوخته کتاب‌ها در هوا می‌چرخیدند.

یحیی از پدربزرگ جدا نمی‌شد. سلطان می‌گفت: «داری بزرگ می‌شوی!»

صبح‌ها وانت قدیمی را روشن می‌کردند و به شهر می‌رفتند. وانت برای سلطان تنها رفیقش بود؛ پیر و زنگ‌زده، اما هنوز سرحال.

یک روز صاحب مغازه آهسته گفت: «بهتره از فردا یحیی را به مدرسه نبری. انگار دوباره جنگ می‌شود.»

سلطان دلشوره گرفت. قول داده بود برای یحیی چند جلد کتاب بخرد، اما حالا فقط می‌خواست زودتر او را به خانه برگرداند.

شب، صدای انفجار شهر را روشن کرد. سلطان به یحیی گفت: «دارند ترقه‌بازی می‌کنند.» اما خودش می‌دانست که ترقه‌ای در کار نیست.

سلطان جنگ‌ها را دیده بود؛ اما این بار ترسش برای خودش نبود. برای یحیی بود.

هرچه به خانه پسرش نزدیک‌تر می‌شد، خرابه‌ها بیشتر می‌شدند. سلطان میان آوار دنبال خانواده‌اش می‌گشت و وقتی کیف پاره‌پاره لیلا را با یک لنگ کفش پیدا کرد، در خودش فرو ریخت.

یحیی بعدها فهمید که پدر، مادر و لیلا دیگر برنمی‌گردند. پدربزرگ آرام به او گفته بود که آنها به دیدار خدا رفته‌اند.

و یحیی روبروی مزارشان ایستاده بود؛ چسبیده به پاهای پدربزرگ.

سلطان گفت: «یحیی، داری بزرگ‌تر می‌شوی. گریه نکن.»
""";
  @Override public void onCreate(Bundle b){ super.onCreate(b); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(245,241,232));
    TextView title=new TextView(this); title.setText("اسم من یحیی است"); title.setTextSize(28); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); title.setGravity(Gravity.CENTER); title.setPadding(16,28,16,18); root.addView(title,new LinearLayout.LayoutParams(-1,-2));
    TextView author=new TextView(this); author.setText("حسین اقبالیان"); author.setTextSize(16); author.setGravity(Gravity.CENTER); root.addView(author,new LinearLayout.LayoutParams(-1,-2));
    ScrollView scroll=new ScrollView(this); TextView text=new TextView(this); text.setText(book); text.setTextSize(20); text.setTextColor(Color.rgb(35,35,35)); text.setGravity(Gravity.RIGHT); text.setLineSpacing(12,1.0f); text.setPadding(24,28,24,60); scroll.addView(text); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root); }
}
